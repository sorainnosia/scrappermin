package com.innosia.myapplication.myapplication;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView txt = (TextView)findViewById(R.id.txtID);
        new HttpAsyncTask(this, txt).execute("https://forums.hardwarezone.com.sg/eat-drink-man-woman-16/");
    }
}
