package com.innosia.myapplication.myapplication;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by innos on 11/9/2018.
 */

public class HttpAsyncTask extends AsyncTask<String, Void, String> {
    private TextView textView;
    private AppCompatActivity activity;
    public HttpAsyncTask(AppCompatActivity act, TextView tv)
    {
        activity = act;
        textView = tv;
    }


    @Override
    protected String doInBackground(String... urls) {
        return ScrapperMinHelper.GetHtml(urls[0]);
    }

    @Override
    protected void onPostExecute(final String result) {
        if (textView == null)return;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textView.setText(result);
            }
        });
    }
}