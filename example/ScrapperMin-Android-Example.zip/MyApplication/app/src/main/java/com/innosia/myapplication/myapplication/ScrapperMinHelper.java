package com.innosia.myapplication.myapplication;

/**
 * Created by innos on 11/9/2018.
 */

import ScrapperMinLib.CookieWebClient;

public class ScrapperMinHelper {
    public static String GetHtml(String url) {
        try
        {
            ScrapperMinLib.CookieWebClient wc = ScrapperMinLib.ScrapperMinLib.initWC();
            String html = wc.methodPage(url, "GET", "", "");

            return html;
        }
        catch (Exception e)
        {
            return "";
        }
    }
}
